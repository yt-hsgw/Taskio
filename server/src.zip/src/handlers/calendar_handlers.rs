//! カレンダー関連のAPIハンドラー
//!
//! カレンダー画面で使用するログ一括取得機能を提供します。

use axum::{
    extract::{Query, State},
    http::StatusCode,
    Json,
};
use chrono::{DateTime, NaiveDate, Utc};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::state::AppState;

/// ログ検索クエリパラメータ
#[derive(Debug, Deserialize)]
pub struct LogsQuery {
    /// 開始日 (YYYY-MM-DD形式)
    pub from: String,
    /// 終了日 (YYYY-MM-DD形式)
    pub to: String,
}

/// カレンダー用ログレスポンス
#[derive(Debug, Serialize)]
pub struct CalendarLogResponse {
    /// ログID
    pub id: String,
    /// タスクID
    pub task_id: String,
    /// タスクタイトル
    pub task_title: String,
    /// タスク説明
    pub task_description: Option<String>,
    /// 開始日時
    pub start_at: Option<DateTime<Utc>>,
    /// 終了日時
    pub end_at: Option<DateTime<Utc>>,
    /// 所要時間（分）
    pub duration_minutes: Option<i32>,
    /// メモ
    pub memo: Option<String>,
    /// 作成日時
    pub created_at: DateTime<Utc>,
}

/// ログ一覧レスポンス
#[derive(Debug, Serialize)]
pub struct CalendarLogsResponse {
    pub logs: Vec<CalendarLogResponse>,
}

/// 期間指定でログを一括取得
///
/// # Arguments
/// * `state` - アプリケーション状態
/// * `query` - 検索クエリ（from, to）
///
/// # Returns
/// 指定期間内のすべてのログ（タスク情報付き）
///
/// # Endpoint
/// `GET /api/v1/logs?from=YYYY-MM-DD&to=YYYY-MM-DD`
pub async fn get_logs_by_date_range(
    State(state): State<Arc<AppState>>,
    Query(query): Query<LogsQuery>,
) -> Result<Json<CalendarLogsResponse>, (StatusCode, String)> {
    // 日付をパース
    let from_date = NaiveDate::parse_from_str(&query.from, "%Y-%m-%d")
        .map_err(|_| {
            (
                StatusCode::BAD_REQUEST,
                "Invalid 'from' date format. Use YYYY-MM-DD".to_string(),
            )
        })?;

    let to_date = NaiveDate::parse_from_str(&query.to, "%Y-%m-%d")
        .map_err(|_| {
            (
                StatusCode::BAD_REQUEST,
                "Invalid 'to' date format. Use YYYY-MM-DD".to_string(),
            )
        })?;

    // from <= to のバリデーション
    if from_date > to_date {
        return Err((
            StatusCode::BAD_REQUEST,
            "'from' date must be before or equal to 'to' date".to_string(),
        ));
    }

    // タスクとログを取得
    let tasks = state.tasks.lock().await;
    let logs = state.task_logs.lock().await;

    let mut calendar_logs: Vec<CalendarLogResponse> = Vec::new();

    for log in logs.values() {
        // 開始日時でフィルタリング
        if let Some(start_at) = log.start_at {
            let log_date = start_at.date_naive();
            
            if log_date >= from_date && log_date <= to_date {
                // タスク情報を取得
                if let Some(task) = tasks.get(&log.task_id) {
                    calendar_logs.push(CalendarLogResponse {
                        id: log.id.to_string(),
                        task_id: log.task_id.to_string(),
                        task_title: task.title.clone(),
                        task_description: task.description.clone(),
                        start_at: log.start_at,
                        end_at: log.end_at,
                        duration_minutes: log.duration_minutes,
                        memo: log.memo.clone(),
                        created_at: log.created_at,
                    });
                }
            }
        }
    }

    // 開始日時でソート（新しい順）
    calendar_logs.sort_by(|a, b| {
        b.start_at.cmp(&a.start_at)
    });

    Ok(Json(CalendarLogsResponse { logs: calendar_logs }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_date_parsing() {
        let date = NaiveDate::parse_from_str("2026-01-25", "%Y-%m-%d");
        assert!(date.is_ok());
        assert_eq!(date.unwrap().to_string(), "2026-01-25");
    }

    #[test]
    fn test_invalid_date_parsing() {
        let date = NaiveDate::parse_from_str("invalid", "%Y-%m-%d");
        assert!(date.is_err());
    }
}
